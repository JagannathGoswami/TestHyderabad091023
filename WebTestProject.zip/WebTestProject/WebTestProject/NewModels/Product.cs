﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebTestProject.NewModels
{
    public class Product
    {
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public string Decription { get; set; }

        public Product()
        {
            ProductName = "P1";
            Price = (decimal)4500.35;
            Decription = "this is laptop pc";
        }
    }
}
