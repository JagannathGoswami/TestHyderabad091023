﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebTestProject.NewModels
{
    public class Offer
    {
        public string OfferName { get; set; }
        public string Products { get; set; }
        public Offer()
        {
            Products = "P1";
            OfferName = "Laptops";
        }
    }
}
