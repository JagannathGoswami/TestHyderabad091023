﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebTestProject.NewModels
{
    public class OfferService
    {
        public List<Product> Inventory { get; set; }
        public OfferService()
        {
            Inventory = AddProducts();
            //GetAllProducts();
        }
        private List<Product> AddProducts()
        {
            List<Product> products = new List<Product>();
            {
                products.Add(new Product { ProductName = "P1", Price =1000 , Decription = "P1 Description" });
                products.Add(new Product { ProductName = "P2", Price = 200, Decription = "P2 Description" });
                products.Add(new Product { ProductName = "P3", Price = 400, Decription = "P3 Description" });
                products.Add(new Product { ProductName = "P4", Price = 700, Decription = "P4 Description" });
                products.Add(new Product { ProductName = "P5", Price = 600, Decription = "P5 Description" });
                products.Add(new Product { ProductName = "P6", Price = 800, Decription = "P6 Description" });
            }

            return products;
            
        }

        public List<Product> GetAllProducts()
        {
            return AddProducts();
        }

        public void GetTodaysOffers(List<Product> lstProducts)
        {
            
        }

        public void AddProduct(Product prod)
        {
            Product products = new Product();
            products.Decription = prod.Decription;
            products.Price = prod.Price;
            products.ProductName = prod.ProductName;
        }

    }

    
}
