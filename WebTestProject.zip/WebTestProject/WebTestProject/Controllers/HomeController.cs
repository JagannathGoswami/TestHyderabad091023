﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebTestProject.Models;
using WebTestProject.NewModels;

namespace WebTestProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IprintInterface _IprintInterface;
        private readonly OfferService _offerService;
        public HomeController(ILogger<HomeController> logger, IprintInterface IprintInterface, OfferService offerService)
        {
            _logger = logger;
            _IprintInterface = IprintInterface;
            _offerService = offerService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            //display fizz and buzz based on business logic
            //==============================================
            var result = _IprintInterface.PrintMessage(1, 100);
            var displayResult = result.Split(";");
            foreach (var item in displayResult)
            {
                Console.WriteLine(item);
            }

            //Display reverse String business logic
            //=======================
            var stringResult = _IprintInterface.ReverseString("abcdef");
            Console.WriteLine(stringResult);


            return View();
        }

        [HttpGet]
        public void GetAllProducts()
        {
            var productList = _offerService.GetAllProducts();
            foreach (var item in productList)
            {
                Console.Write(item.ProductName);
                Console.Write(item.Price);
                Console.Write(item.Decription);
                Console.WriteLine("-------------");
            }

        }
        [HttpGet]
        public Product GetProduct()
        {
            var product = _offerService.GetAllProducts().OrderBy(z => z.Price).Skip(1).Take(1).FirstOrDefault();
            return product;
        }

        [HttpPost]
        public void AddProduct()
        {
            Product product = new Product();
            product.ProductName = "NewPC";
            product.Decription = "New Description";
            product.Price = (decimal)2283948.00;

            _offerService.AddProduct(product);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
